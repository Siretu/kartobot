/* OpenServo I2C Test Code 
 * Written for use with LPC2138 development board (SparkFun SKU# DEV-00272)
 * Tests OpenServo board by changing servo position
 * 
 * Written by Chris Taylor, 12/15/08 for SparkFun Electronics 
 * Use in conjunction with I2C routines written by David Wolpoff 
 * 	(see README.txt for legal mumbo-jumbo on NewLib and I2C routines)
 */

#include <stdio.h>
#include "LPC214x.h"
#include "system.h"
#include "intcomm.h"
#include "iic.h"
#include "printmacros.h"
#include "servo.h"

int main(void)
{
  unsigned char data[3]={0,0,0};

/* Do basic initialization */
  boot_up(); /* From system.c */

/* Initialize IIC Module */
  i2c0_init();  /* From iic.c */
  i2c0ISR_init(); /* From iic.c */

  PRINTF0("I2C started\n\r");

  data[0] = WRITE_ENABLE;
  i2c0_master_send(TWI_ADDRESS, data, 1); // Allow writing to protected registers
  delay_ms(5);
  
  data[0] = PWM_ENABLE;
  i2c0_master_send(TWI_ADDRESS, data, 1); // Enable PWM
  delay_ms(5);

  data[0] = PID_PGAIN_HI;
  data[1] = 0x01;
  data[2] = 0x90;
  i2c0_master_send(TWI_ADDRESS, data, 3); // Set PGain to 400
  delay_ms(5);


  data[0] = PID_DGAIN_HI;
  i2c0_master_send(TWI_ADDRESS, data, 3); // Set DGain to 400
  delay_ms(5);

  //while(1)
  //{
  	 delay_ms(2000);
	 data[0] = SEEK_HI;
	 data[1] = 0x02;
	 data[2] = 0xFF;
	 PRINTF0("Changing Position...\n\r");
	 if(i2c0_master_send(0x20,data,3)){ PRINTF0("ERROR"); }
  
	 delay_ms(2000);
	 data[0] = SEEK_HI;
	 data[1] = 0x02;
	 data[2] = 0x00;
	 PRINTF0("Changing Position...\n\r");
	 if(i2c0_master_send(0x20,data,3)){ PRINTF0("ERROR"); }
 //}
  while(1);
  
}

